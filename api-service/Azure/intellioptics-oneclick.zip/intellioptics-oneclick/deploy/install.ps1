# Runs the one-click installer from PowerShell (requires WSL or bash)
bash ./deploy/install.sh
