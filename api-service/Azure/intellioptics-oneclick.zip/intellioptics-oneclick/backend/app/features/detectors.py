from ..clients.intellioptics_client import io_client

def ensure_basic_detector(name: str, query: str, confidence: float = 0.9):
    det = io_client().get_or_create_detector(name=name, query=query, confidence_threshold=confidence)
    return det
