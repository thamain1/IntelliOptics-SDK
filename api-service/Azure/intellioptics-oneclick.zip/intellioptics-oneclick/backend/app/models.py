from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import String, Float, Boolean
from sqlalchemy.dialects.postgresql import JSONB
from .db import Base

class ImageQueryRow(Base):
    __tablename__ = "image_queries"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    detector_id: Mapped[str] = mapped_column(String, index=True)
    blob_url: Mapped[str] = mapped_column(String)
    status: Mapped[str] = mapped_column(String, default="SUBMITTED")
    label: Mapped[str | None] = mapped_column(String, nullable=True)
    confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    result_type: Mapped[str | None] = mapped_column(String, nullable=True)
    count: Mapped[float | None] = mapped_column(Float, nullable=True)
    extra = mapped_column(JSONB, nullable=True)
    done_processing: Mapped[bool] = mapped_column(Boolean, default=False)
    human_label: Mapped[str | None] = mapped_column(String, nullable=True)
    human_confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    human_notes: Mapped[str | None] = mapped_column(String, nullable=True)
    human_user: Mapped[str | None] = mapped_column(String, nullable=True)
