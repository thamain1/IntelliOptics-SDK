from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient
from ..config import settings
import uuid

_cred = DefaultAzureCredential(exclude_shared_token_cache_credential=True)

if settings.blob_conn_str:
    _svc = BlobServiceClient.from_connection_string(settings.blob_conn_str)
else:
    _svc = BlobServiceClient(f"https://{settings.blob_account}.blob.core.windows.net", credential=_cred)

container = _svc.get_container_client(settings.blob_container)
container.create_container(exist_ok=True)

async def save_image_bytes(data: bytes, content_type: str = "image/jpeg") -> str:
    blob_name = f"uploads/{uuid.uuid4()}.jpg"
    blob = container.get_blob_client(blob_name)
    blob.upload_blob(data, overwrite=False, content_type=content_type)
    return blob.url
