from fastapi import FastAPI, UploadFile, File, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .schemas import SubmitQueryResponse, QueryStatusResponse, HumanLabelRequest
from .auth import require_auth
from .storage.blob import save_image_bytes
from .queues.servicebus import enqueue_image_query, enqueue_feedback
from .db import SessionLocal, Base, engine
from .models import ImageQueryRow
from .clients.intellioptics_client import io_client
from .migrations import migrate

Base.metadata.create_all(bind=engine)
migrate()

def create_app():
    app = FastAPI(title="IntelliOptics Backend", version="0.2.0")
    app.add_middleware(CORSMiddleware, allow_origins=[settings.allowed_origins] if settings.allowed_origins != "*" else ["*"], allow_methods=["*"], allow_headers=["*"])

    @app.post(f"{settings.api_base_path}/image-queries", response_model=SubmitQueryResponse, dependencies=[Depends(require_auth)])
    async def submit_image_query(detector_id: str, image: UploadFile = File(...)):
        content = await image.read()
        blob_url = await save_image_bytes(content, image.content_type or "image/jpeg")
        payload = {"detector_id": detector_id, "blob_url": blob_url}
        await enqueue_image_query(payload)
        return SubmitQueryResponse(image_query_id="queued", status="QUEUED")

    @app.get(f"{settings.api_base_path}/image-queries/{{image_query_id}}", response_model=QueryStatusResponse, dependencies=[Depends(require_auth)])
    async def get_status(image_query_id: str):
        with SessionLocal() as db:
            row = db.get(ImageQueryRow, image_query_id)
            if not row:
                iq = io_client().get_image_query(image_query_id)
                return QueryStatusResponse(
                    id=iq.id,
                    status="DONE" if iq.done_processing else "PROCESSING",
                    label=(iq.result.label if iq.result else None),
                    confidence=(iq.result.confidence if iq.result else None),
                    result_type=iq.result_type,
                    count=getattr(getattr(iq, "result", None), "count", None),
                    extra=None,
                )
            return QueryStatusResponse(id=row.id, status=row.status, label=row.label, confidence=row.confidence, result_type=row.result_type, count=row.count, extra=row.extra)

    @app.post(f"{settings.api_base_path}/image-queries/{{image_query_id}}/human-label", dependencies=[Depends(require_auth)])
    async def human_label(image_query_id: str, body: HumanLabelRequest):
        with SessionLocal() as db:
            row = db.get(ImageQueryRow, image_query_id)
            if not row:
                raise HTTPException(404, detail="image_query not found")
            row.human_label = body.label
            row.human_confidence = body.confidence
            row.human_notes = body.notes
            row.human_user = body.user
            if body.count is not None:
                row.count = body.count
            if body.extra is not None:
                row.extra = body.extra
            db.add(row); db.commit()
        await enqueue_feedback({
            "image_query_id": image_query_id,
            "label": body.label,
            "confidence": body.confidence,
            "count": body.count,
            "notes": body.notes,
            "user": body.user,
        })
        return {"ok": True}

    @app.post("/webhooks/intellioptics")
    async def webhook_ingest(payload: dict):
        return {"ok": True}

    return app
