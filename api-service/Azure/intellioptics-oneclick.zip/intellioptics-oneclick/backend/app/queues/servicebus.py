from azure.servicebus import ServiceBusClient, ServiceBusMessage
from azure.identity import DefaultAzureCredential
from ..config import settings

_cred = DefaultAzureCredential(exclude_shared_token_cache_credential=True)

if settings.sb_conn_str:
    _sb = ServiceBusClient.from_connection_string(settings.sb_conn_str)
else:
    if not settings.sb_namespace:
        raise RuntimeError("Provide SERVICE_BUS_CONN or AZ_SB_NAMESPACE")
    _sb = ServiceBusClient(fully_qualified_namespace=f"{settings.sb_namespace}.servicebus.windows.net", credential=_cred)

_img_sender = _sb.get_queue_sender(settings.sb_image_queue)
_res_sender = _sb.get_queue_sender(settings.sb_results_queue)
_fb_sender = _sb.get_queue_sender(settings.sb_feedback_queue)

async def enqueue_image_query(payload: dict):
    with _img_sender:
        _img_sender.send_messages(ServiceBusMessage(payload | {"kind": "image-query"}))

async def enqueue_result(payload: dict):
    with _res_sender:
        _res_sender.send_messages(ServiceBusMessage(payload | {"kind": "result"}))

async def enqueue_feedback(payload: dict):
    with _fb_sender:
        _fb_sender.send_messages(ServiceBusMessage(payload | {"kind": "feedback"}))
