from intellioptics import IntelliOptics, ExperimentalApi
from ..config import settings

_io = IntelliOptics(endpoint=settings.io_endpoint or None, api_token=settings.io_token)
_exp = ExperimentalApi(endpoint=settings.io_endpoint or None, api_token=settings.io_token)

def io_client() -> IntelliOptics:
    return _io

def exp_client() -> ExperimentalApi:
    return _exp
