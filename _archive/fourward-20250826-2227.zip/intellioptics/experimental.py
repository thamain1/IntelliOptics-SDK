class ExperimentalApi:
    def __init__(self, client):
        self.client = client

    def create_alert_rule(self, **kwargs):
        raise NotImplementedError("Experimental feature not yet implemented.")
