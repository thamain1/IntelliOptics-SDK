def get_headers(token: str):
    return {"Authorization": f"Bearer {token}"}
